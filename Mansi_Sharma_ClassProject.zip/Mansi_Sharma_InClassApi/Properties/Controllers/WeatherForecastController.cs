﻿namespace Mansi_Sharma_InClassApi.Properties.Controllers
{
    public class WeatherForecast
    {
    }
}
