﻿namespace Mansi_Sharma_InClassApi.Properties.Migrations
{
    public class WeatherForecast
    {
    }
}
